from django.db import models

# Create your models here.


class ShowsManager(models.Manager):
    def show_validator(self, postData):
        errors = {}
        if len(postData['title']) < 1:
            errors["title"] = "Title name can not empty"
        if len(postData['network']) < 1:
            errors["network"] = "Network name can not be empty"
        if len(postData['desc']) < 5:
            errors["desc"] = "Description should be atleast 5 character"
        return errors


class Shows(models.Model):
    title = models.CharField(max_length=255)
    network = models.CharField(max_length=255)
    release_date = models.DateTimeField()
    desc = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = ShowsManager()
