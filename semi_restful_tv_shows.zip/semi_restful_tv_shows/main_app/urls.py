from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('add', views.add),
    path('create', views.create),
    path('edit/<int:show_id>', views.edit),
    path('update/<int:show_id>', views.update),
    path('<int:show_id>', views.show),
    path('delete/<int:show_id>', views.delete),
]
